/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.BufferedReader;
//import static com.sun.xml.internal.ws.spi.db.BindingContextFactory.LOGGER;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Paths;
import javax.json.Json;
import javax.json.JsonObject;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.MultiPart;
import org.glassfish.jersey.media.multipart.MultiPartFeature;




/**
 *
 * @author alumne
 */
@WebServlet(name = "registrarimagen", urlPatterns = {"/registrarimagen"})
@MultipartConfig
public class registrarimagen extends HttpServlet {

   

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        boolean correctUpload = true;
        try {
            // Obtencion de parametros de la peticion del jsp necesarios para realizar las llamadas al servicio REST
            HttpSession session = request.getSession();
            String nombreUsuarioActual = session.getAttribute("user").toString();  
            String title = request.getParameter("title");
            String author = request.getParameter("author");
            float price = Float.parseFloat(request.getParameter("price"));
            boolean reserved = true;
            if (request.getParameter("reserved") == null){
                reserved = false;
            }
            
            JsonObject json = Json.createObjectBuilder()
                    .add("autor", author)
                    .add("titulo", title)
                    .add("precio", Float.toString(price)).
                    add("reservado", String.valueOf(reserved))
                    .build();
            
            String jsonInputString =  json.toString();
            //Preparamos la conexion Http
            URL url = new URL("http://localhost:8000/imagenes/");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Content-Type", "application/json;utf-8" );

            // enviamos la peticion al servicio REST via connection OutputStream
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            
            //Obtenemos la respuesta del servicio REST y la escribimos 
            try(BufferedReader br = new BufferedReader(
             new InputStreamReader(conn.getInputStream(), "utf-8"))) {
                StringBuilder respuesta = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    respuesta.append(responseLine.trim());
                }
                System.out.println(response.toString());
            }
            
            conn.disconnect();

        } catch (Exception e) {
            System.out.println(e.getMessage());
            correctUpload = false;
            response.sendRedirect("error.jsp?tipo=registrarimagen");
        }
        
    }

 
    
    

    
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        processRequest(request, response);
         PrintWriter out = response.getWriter();

         
       
         out.println("<html> <body>"
                        + "<br>"
                        + "<a href='registrarimagen.jsp'> Ir a registar imagen </a>"
                        + "<br>"
                        + "<a href='menu.jsp'> Volver al menu</a> "
                        + "<br>"
                        + "</body></html>");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
