/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import javax.json.Json;
import javax.json.JsonObject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.*;

/**
 *
 * @author alumne
 */
@WebServlet(name = "modificar", urlPatterns = {"/modificar"})
public class modificar extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        try {
            // Obtencion de parametros de la peticion del jsp necesarios para realizar las llamadas al servicio REST 
            String title = request.getParameter("titulo");
            String author = request.getParameter("autor");
            float price = Float.parseFloat(request.getParameter("precio"));
            String id = request.getParameter("id");
            boolean reserved = true;
            if (request.getParameter("reserved") == null){
                reserved = false;
            }
            
            //Creamos el nuevo objeto json
            JSONObject json = new JSONObject();
            if (author != "") {
                json.put("autor", author);
            }
            if (title != ""){
                json.put("titulo", title);
            }
            if (price >= 0){
                String precio_string = Float.toString(price);
                json.put("precio", precio_string);
            }
            json.put("reservado", String.valueOf(reserved));
            json.put("id", id);
            String jsonInputString =  json.toString();
            System.out.print(jsonInputString);
            
            //Preparamos la conexion Http
            URL url = new URL("http://127.0.0.1:8000/imagenes/" + id + "/");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("PUT");
            conn.setDoOutput(true);
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Content-Type", "application/json;utf-8" );
            
            // enviamos la peticion al servicio REST via connection OutputStream
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            
            //Obtenemos la respuesta del servicio REST y la escribimos 
            try(BufferedReader br = new BufferedReader(
             new InputStreamReader(conn.getInputStream(), "utf-8"))) {
                StringBuilder respuesta = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    respuesta.append(responseLine.trim());
                }
                System.out.println(response.toString());
            }
            
            conn.disconnect();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            response.sendRedirect("error.jsp?tipo=registrarimagen");
        }
        
        try (PrintWriter out = response.getWriter()) {
                out.println("Imagen modificada correctamente, pulse "
                + "<a href='menu.jsp'>aquí</a>"
                + " para volver al menú");
            } catch (Exception e){
                System.err.println(e.getMessage());
            }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
